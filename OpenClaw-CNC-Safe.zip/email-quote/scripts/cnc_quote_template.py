#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CNC Quote Generator - 匹配专业报价单模板
参考 Singapore CNC Tech 报价单格式
"""

import os
import sys
import json
import re
from datetime import datetime
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

try:
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("需要安装openpyxl: pip install openpyxl")
    sys.exit(1)

HOME = Path.home()
WORK_DIR = HOME / ".openclaw/skills/email-quote/workspace/quotes"

class CNCQuoteGenerator:
    """CNC专业报价单生成器"""
    
    def __init__(self):
        self.date = datetime.now()
        self.tracking_id = f"CNC{self.date.strftime('%Y%m%d%H%M%S')}"
        self.config = self.load_config()
    
    def load_config(self):
        config_path = HOME / ".openclaw/skills/email-quote/config/email_config.json"
        if config_path.exists():
            with open(config_path) as f:
                return json.load(f)
        return {"email_addr": "849355070@qq.com"}
    
    def calc_quote(self, material, surface, quantity, tolerance="ISO 2768 普通级"):
        """计算报价"""
        sys.path.insert(0, str(HOME / ".openclaw/skills/metal-kbs/scripts"))
        from knowledge_graph import MetalKBS
        
        kbs = MetalKBS()
        
        # 获取系数
        mat_coef, surf_coef, _ = kbs.get_price_coef(material, surface)
        
        # 基准价
        median_price, _ = kbs.get_median_price()
        
        # 计算
        base = median_price * mat_coef
        surface_cost = base * surf_coef
        unit_price = base + surface_cost
        
        # 转换为RMB/件
        qty = int(quantity) if quantity else 1
        total_without_tax = unit_price * qty
        gst_rate = 0.00  # 中国市场不收GST
        gst_amount = total_without_tax * gst_rate
        total_with_tax = total_without_tax + gst_amount
        
        return {
            "unit_price": round(unit_price, 2),
            "qty": qty,
            "total_without_tax": round(total_without_tax, 2),
            "gst_rate": gst_rate,
            "gst_amount": round(gst_amount, 2),
            "total_with_tax": round(total_with_tax, 2),
            "material": material,
            "surface": surface,
            "tolerance": tolerance,
        }
    
    def generate_xlsx(self, part_info, quote_data, output_path=None):
        """生成专业XLSX报价单"""
        WORK_DIR.mkdir(parents=True, exist_ok=True)
        
        if not output_path:
            output_path = WORK_DIR / f"Quote_{self.tracking_id}.xlsx"
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "CNC 报价单"
        
        # 列宽
        widths = [18, 15, 12, 10, 15, 15, 12, 15]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        
        # 样式
        title_font = Font(size=16, bold=True, color="FFFFFF")
        title_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        header_font = Font(size=11, bold=True)
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        money_font = Font(size=11)
        total_font = Font(size=12, bold=True, color="FFFFFF")
        total_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # === 标题 ===
        ws.merge_cells('A1:H1')
        ws['A1'] = "CNC 加工报价单"
        ws['A1'].font = title_font
        ws['A1'].fill = title_fill
        ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[1].height = 30
        
        # 公司名
        ws.merge_cells('A2:H2')
        ws['A2'] = f"{self.config.get('company_name', 'timo报价智能自动报价系统')}"
        ws['A2'].alignment = Alignment(horizontal='center')
        ws.row_dimensions[2].height = 20
        
        # 报价日期和追踪ID
        ws['A4'] = "报价日期:"
        ws['A4'].font = header_font
        ws['B4'] = self.date.strftime("%Y-%m-%d %H:%M")
        ws['E4'] = "追踪 ID:"
        ws['E4'].font = header_font
        ws['F4'] = self.tracking_id
        
        # === 零件信息区域 ===
        ws['A6'] = "零件信息"
        ws['A6'].font = header_font
        ws['A6'].fill = header_fill
        ws.merge_cells('A6:D6')
        
        info_labels = ["材料", "数量", "公差等级", "表面处理", "加工方式", "重量", "体积"]
        info_values = [
            part_info.get("material", ""),
            str(quote_data["qty"]),
            part_info.get("tolerance", "ISO 2768 普通级"),
            part_info.get("surface", ""),
            "CNC_3AXIS",
            part_info.get("weight", "-"),
            part_info.get("volume", "-"),
        ]
        
        for i, (label, value) in enumerate(zip(info_labels, info_values), 7):
            ws[f'A{i}'] = label
            ws[f'A{i}'].font = header_font
            ws.merge_cells(f'B{i}:D{i}')
            ws[f'B{i}'] = value
        
        # === 订单信息区域 ===
        ws['F6'] = "订单信息"
        ws['F6'].font = header_font
        ws['F6'].fill = header_fill
        ws.merge_cells('F6:H6')
        
        order_labels = ["数量", "地区", "GST税率"]
        order_values = [
            str(quote_data["qty"]),
            "中国",
            f"{quote_data['gst_rate']*100:.2f}%" if quote_data['gst_rate'] > 0 else "0.00%",
        ]
        
        for i, (label, value) in enumerate(zip(order_labels, order_values), 7):
            ws[f'F{i}'] = label
            ws[f'F{i}'].font = header_font
            ws.merge_cells(f'G{i}:H{i}')
            ws[f'G{i}'] = value
        
        # === 成本明细表头 ===
        header_row = 15
        ws.merge_cells(f'A{header_row}:H{header_row}')
        ws[f'A{header_row}'] = "成本明细"
        ws[f'A{header_row}'].font = header_font
        ws[f'A{header_row}'].fill = header_fill
        
        # 表头
        cost_headers = ["项目", "不含税单价(RMB)", "含税单价(RMB)", "数量", "不含税总金额", "含税总金额", "", ""]
        for col, header in enumerate(cost_headers, 1):
            cell = ws.cell(row=header_row+1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center')
        
        # === 零件明细行 ===
        item_row = header_row + 2
        item_name = f"零件报价_{part_info.get('material', '材料')}_{quote_data['qty']}件"
        
        ws.cell(row=item_row, column=1, value=item_name).border = thin_border
        ws.cell(row=item_row, column=2, value=quote_data["unit_price"]).border = thin_border
        ws.cell(row=item_row, column=3, value=quote_data["unit_price"]).border = thin_border  # 同价
        ws.cell(row=item_row, column=4, value=quote_data["qty"]).border = thin_border
        ws.cell(row=item_row, column=5, value=quote_data["total_without_tax"]).border = thin_border
        ws.cell(row=item_row, column=6, value=quote_data["total_with_tax"]).border = thin_border
        
        # 金额格式化
        for col in [2, 3, 5, 6]:
            ws.cell(row=item_row, column=col).number_format = '#,##0.00'
        
        # === 汇总行 ===
        summary_row = item_row + 2
        
        ws.cell(row=summary_row, column=4, value="小计:").font = Font(bold=True)
        ws.cell(row=summary_row, column=5, value=quote_data["total_without_tax"]).number_format = '#,##0.00'
        ws.cell(row=summary_row, column=5).font = Font(bold=True)
        
        if quote_data['gst_rate'] > 0:
            ws.cell(row=summary_row+1, column=4, value=f"GST ({quote_data['gst_rate']*100:.0f}%):")
            ws.cell(row=summary_row+1, column=6, value=quote_data["gst_amount"]).number_format = '#,##0.00'
        
        # 总计行
        total_row = summary_row + 2
        ws.merge_cells(f'A{total_row}:D{total_row}')
        ws[f'A{total_row}'] = "总计 (RMB)"
        ws[f'A{total_row}'].font = total_font
        ws[f'A{total_row}'].fill = total_fill
        ws.cell(row=total_row, column=6, value=quote_data["total_with_tax"])
        ws.cell(row=total_row, column=6).font = total_font
        ws.cell(row=total_row, column=6).fill = total_fill
        ws.cell(row=total_row, column=6).number_format = '#,##0.00'
        ws.row_dimensions[total_row].height = 25
        
        # === 备注 ===
        notes_row = total_row + 2
        ws.merge_cells(f'A{notes_row}:H{notes_row}')
        ws[f'A{notes_row}'] = "备注:"
        ws[f'A{notes_row}'].font = header_font
        
        notes = [
            f"1. 材料: {part_info.get('material', '-')} | 表面处理: {part_info.get('surface', '-')}",
            f"2. 公差: {part_info.get('tolerance', 'ISO 2768 普通级')}",
            "3. 含税单价已包含表面处理费用",
            "4. 报价有效期: 7天",
        ]
        for i, note in enumerate(notes, notes_row+1):
            ws.merge_cells(f'A{i}:H{i}')
            ws[f'A{i}'] = note
        
        wb.save(str(output_path))
        return output_path
    
    def send_quote_email(self, to_email, subject, quote_data, xlsx_path):
        """发送报价邮件"""
        from knowledge_graph import MetalKBS
        
        smtp_config = self.config
        smtp_config["smtp_server"] = "smtp.qq.com"
        smtp_config["smtp_port"] = 465
        
        # 邮件正文
        body = f"""您好，

感谢您的询价！请查收附件中的专业CNC加工报价单。

报价概要:
━━━━━━━━━━━━━━━━━━━━━
追踪ID: {self.tracking_id}
材料: {quote_data['material']}
数量: {quote_data['qty']}件
不含税总价: ¥{quote_data['total_without_tax']:.2f}
含税总价: ¥{quote_data['total_with_tax']:.2f}
━━━━━━━━━━━━━━━━━━━━━

报价单包含详细成本明细、交货周期及付款条款。

如有任何疑问，请回复此邮件。

此致

智能报价系统
"""
        
        try:
            import smtplib, ssl
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
            from email.mime.base import MIMEBase
            from email import encoders
            
            ctx = ssl.create_default_context()
            smtp = smtplib.SMTP_SSL(smtp_config["smtp_server"], smtp_config["smtp_port"], context=ctx)
            smtp.login(smtp_config["email_addr"], smtp_config["auth_code"])
            
            msg = MIMEMultipart()
            msg['From'] = smtp_config["email_addr"]
            msg['To'] = to_email
            msg['Subject'] = f"Re: {subject} - CNC报价单 {self.tracking_id}"
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # 添加附件
            with open(xlsx_path, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename=Quote_{self.tracking_id}.xlsx')
                msg.attach(part)
            
            smtp.send_message(msg)
            smtp.quit()
            
            print(f"✅ 报价已发送至 {to_email}")
            return True
        except Exception as e:
            print(f"❌ 发送失败: {e}")
            return False

def main():
    if len(sys.argv) < 4:
        print("用法: python3 cnc_quote_template.py <材料> <表面处理> <数量>")
        print("示例: python3 cnc_quote_template.py AL6061 anodize_black 10")
        sys.exit(1)
    
    material = sys.argv[1]
    surface = sys.argv[2]
    quantity = int(sys.argv[3])
    
    generator = CNCQuoteGenerator()
    
    # 计算报价
    quote = generator.calc_quote(material, surface, quantity)
    
    print(f"\n=== CNC报价单生成 ===")
    print(f"追踪ID: {generator.tracking_id}")
    print(f"材料: {material}")
    print(f"表面处理: {surface}")
    print(f"数量: {quantity}件")
    print(f"不含税单价: ¥{quote['unit_price']:.2f}")
    print(f"不含税总价: ¥{quote['total_without_tax']:.2f}")
    print(f"含税总价: ¥{quote['total_with_tax']:.2f}")
    
    # 生成XLSX
    part_info = {
        "material": material,
        "surface": surface,
        "tolerance": "ISO 2768 普通级",
    }
    
    xlsx_path = generator.generate_xlsx(part_info, quote)
    print(f"\n✅ 报价单已生成: {xlsx_path}")
    
    return xlsx_path

if __name__ == "__main__":
    main()