#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Email Quote Worker V2 - 专业CNC报价单模板版
匹配 Singapore CNC Tech 报价单格式
"""

import os, sys, re, json, time, email, sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

HOME = Path.home()
SKILL_DIR = HOME / ".openclaw/skills/email-quote"
CONFIG_FILE = SKILL_DIR / "config/email_config.json"
DB_FILE = SKILL_DIR / "config/quote_tasks.db"
WORK_DIR = SKILL_DIR / "workspace"
QUOTE_DIR = WORK_DIR / "quotes"

CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
WORK_DIR.mkdir(parents=True, exist_ok=True)
QUOTE_DIR.mkdir(parents=True, exist_ok=True)

def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f: return json.load(f)
    return {}

class CNCQuoteGenerator:
    """专业CNC报价单生成器"""
    
    def __init__(self):
        self.date = datetime.now()
        self.tracking_id = f"CNC{self.date.strftime('%Y%m%d%H%M%S')}"
        self.config = load_config()
        self.company_name = self.config.get("company_name", "智造报价系统")
    
    def calc_quote(self, material, surface, quantity):
        """调用KBS计算报价"""
        sys.path.insert(0, str(HOME / ".openclaw/skills/metal-kbs/scripts"))
        from knowledge_graph import MetalKBS
        
        kbs = MetalKBS()
        mat_coef, surf_coef, _ = kbs.get_price_coef(material, surface)
        median_price, _ = kbs.get_median_price()
        
        base = median_price * mat_coef
        surface_cost = base * surf_coef
        unit_price = base + surface_cost
        qty = int(quantity) if quantity else 1
        
        total_without_tax = unit_price * qty
        gst_rate = 0.00
        gst_amount = total_without_tax * gst_rate
        total_with_tax = total_without_tax + gst_amount
        
        return {
            "unit_price": round(unit_price, 2),
            "qty": qty,
            "total_without_tax": round(total_without_tax, 2),
            "gst_rate": gst_rate,
            "gst_amount": round(gst_amount, 2),
            "total_with_tax": round(total_with_tax, 2),
            "material": material,
            "surface": surface,
        }
    
    def generate_xlsx(self, part_info, quote_data):
        """生成专业XLSX"""
        try:
            import openpyxl
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
        except:
            print("需要openpyxl")
            return None
        
        output_path = QUOTE_DIR / f"Quote_{self.tracking_id}.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "CNC 报价单"
        
        # 列宽
        for i, w in enumerate([18, 15, 12, 10, 15, 15, 12, 15], 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        
        # 样式
        title_font = Font(size=16, bold=True, color="FFFFFF")
        title_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        header_font = Font(size=11, bold=True)
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        total_font = Font(size=12, bold=True, color="FFFFFF")
        total_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        thin = Border(left=Side(style='thin'), right=Side(style='thin'),
                      top=Side(style='thin'), bottom=Side(style='thin'))
        
        # 标题
        ws.merge_cells('A1:H1')
        ws['A1'] = "CNC 加工报价单"
        ws['A1'].font = title_font
        ws['A1'].fill = title_fill
        ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[1].height = 30
        
        # 公司名
        ws.merge_cells('A2:H2')
        ws['A2'] = self.company_name
        ws['A2'].alignment = Alignment(horizontal='center')
        
        # 日期和追踪ID
        ws['A4'] = "报价日期:"
        ws['A4'].font = header_font
        ws['B4'] = self.date.strftime("%Y-%m-%d %H:%M")
        ws['E4'] = "追踪 ID:"
        ws['E4'].font = header_font
        ws['F4'] = self.tracking_id
        
        # 零件信息
        ws.merge_cells('A6:D6')
        ws['A6'] = "零件信息"
        ws['A6'].font = header_font
        ws['A6'].fill = header_fill
        
        part_labels = ["材料", "数量", "公差等级", "表面处理", "加工方式"]
        part_values = [
            part_info.get("material", ""),
            str(quote_data["qty"]),
            part_info.get("tolerance", "ISO 2768 普通级"),
            part_info.get("surface", ""),
            "CNC_3AXIS",
        ]
        for i, (l, v) in enumerate(zip(part_labels, part_values), 7):
            ws[f'A{i}'] = l
            ws[f'A{i}'].font = header_font
            ws.merge_cells(f'B{i}:D{i}')
            ws[f'B{i}'] = v
        
        # 订单信息
        ws.merge_cells('F6:H6')
        ws['F6'] = "订单信息"
        ws['F6'].font = header_font
        ws['F6'].fill = header_fill
        
        order_labels = ["数量", "地区", "GST税率"]
        order_values = [str(quote_data["qty"]), "中国", "0.00%"]
        for i, (l, v) in enumerate(zip(order_labels, order_values), 7):
            ws[f'F{i}'] = l
            ws[f'F{i}'].font = header_font
            ws.merge_cells(f'G{i}:H{i}')
            ws[f'G{i}'] = v
        
        # 成本明细表头
        ws.merge_cells('A13:H13')
        ws['A13'] = "成本明细"
        ws['A13'].font = header_font
        ws['A13'].fill = header_fill
        
        headers = ["项目", "不含税单价(RMB)", "含税单价(RMB)", "数量", "不含税总金额", "含税总金额", "", ""]
        for col, h in enumerate(headers, 1):
            c = ws.cell(row=14, column=col, value=h)
            c.font = header_font
            c.fill = header_fill
            c.border = thin
        
        # 零件明细
        item_name = f"零件_{part_info.get('material', '材料')}_{quote_data['qty']}件"
        row = 16
        for col, val in [(1, item_name), (2, quote_data["unit_price"]), (3, quote_data["unit_price"]),
                         (4, quote_data["qty"]), (5, quote_data["total_without_tax"]), (6, quote_data["total_with_tax"])]:
            ws.cell(row=row, column=col, value=val).border = thin
            if col in [2, 3, 5, 6]:
                ws.cell(row=row, column=col).number_format = '#,##0.00'
        
        # 汇总
        ws.cell(row=18, column=4, value="小计:").font = Font(bold=True)
        ws.cell(row=18, column=5, value=quote_data["total_without_tax"]).number_format = '#,##0.00'
        ws.cell(row=18, column=5).font = Font(bold=True)
        
        # 总计
        ws.merge_cells('A20:D20')
        ws['A20'] = "总计 (RMB)"
        ws['A20'].font = total_font
        ws['A20'].fill = total_fill
        ws.cell(row=20, column=6, value=quote_data["total_with_tax"])
        ws.cell(row=20, column=6).font = total_font
        ws.cell(row=20, column=6).fill = total_fill
        ws.cell(row=20, column=6).number_format = '#,##0.00'
        ws.row_dimensions[20].height = 25
        
        # 备注
        ws.merge_cells('A22:H22')
        ws['A22'] = "备注:"
        ws['A22'].font = header_font
        
        notes = [
            f"1. 材料: {part_info.get('material')} | 表面处理: {part_info.get('surface')}",
            f"2. 公差: {part_info.get('tolerance', 'ISO 2768 普通级')}",
            "3. 含税单价已包含表面处理费用",
            "4. 报价有效期: 7天",
        ]
        for i, note in enumerate(notes, 23):
            ws.merge_cells(f'A{i}:H{i}')
            ws[f'A{i}'] = note
        
        wb.save(str(output_path))
        return output_path
    
    def send_email(self, to_email, subject, quote_data, xlsx_path):
        """发送邮件"""
        config = self.config
        try:
            import smtplib, ssl
            
            body = f"""您好，

感谢您的询价！请查收附件中的专业CNC加工报价单。

报价概要:
━━━━━━━━━━━━━━━━━━━━
追踪ID: {self.tracking_id}
材料: {quote_data['material']}
数量: {quote_data['qty']}件
不含税总价: ¥{quote_data['total_without_tax']:.2f}
含税总价: ¥{quote_data['total_with_tax']:.2f}
━━━━━━━━━━━━━━━━━━━━

报价单包含详细成本明细。

如有任何疑问，请回复此邮件。

此致

timo报价智能自动报价
"""
            ctx = ssl.create_default_context()
            smtp = smtplib.SMTP_SSL("smtp.qq.com", 465, context=ctx)
            smtp.login(config["email_addr"], config["auth_code"])
            
            msg = MIMEMultipart()
            msg['From'] = config["email_addr"]
            msg['To'] = to_email
            msg['Subject'] = f"Re: {subject} - CNC报价单 {self.tracking_id}"
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            if xlsx_path and os.path.exists(xlsx_path):
                with open(xlsx_path, 'rb') as f:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(f.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f'attachment; filename=Quote_{self.tracking_id}.xlsx')
                    msg.attach(part)
            
            smtp.send_message(msg)
            smtp.quit()
            return True
        except Exception as e:
            print(f"发送失败: {e}")
            return False

class EmailQuoteWorkerV2:
    def __init__(self):
        self.config = load_config()
        self.db = self.init_db()
        self.quote_gen = CNCQuoteGenerator()
        self.logs = []
    
    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        self.logs.append(line)
        print(line)
    
    def init_db(self):
        conn = sqlite3.connect(str(DB_FILE))
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS tasks_v2 (
                id INTEGER PRIMARY KEY,
                customer_email TEXT,
                subject TEXT,
                received_at TEXT,
                status TEXT DEFAULT 'pending',
                material TEXT,
                quantity TEXT,
                tolerance TEXT,
                surface TEXT,
                ra TEXT,
                step_file TEXT,
                retry_count INTEGER DEFAULT 0,
                tracking_id TEXT,
                updated_at TEXT
            )
        """)
        conn.commit()
        return conn
    
    def connect_imap(self):
        import imaplib, ssl
        try:
            ctx = ssl.create_default_context()
            imap = imaplib.IMAP4_SSL("imap.qq.com", 993, ssl_context=ctx)
            imap.login(self.config["email_addr"], self.config["auth_code"])
            self.log(f"✅ IMAP连接: {self.config['email_addr']}")
            return imap
        except Exception as e:
            self.log(f"❌ IMAP失败: {e}")
            return None
    
    def process_email(self, msg_id, imap):
        """处理单封邮件"""
        status, data = imap.fetch(msg_id, '(RFC822)')
        if status != 'OK': return None
        
        raw = data[0][1]
        msg = email.message_from_bytes(raw)
        
        subject = str(msg['Subject'] or "无主题")
        sender = email.utils.parseaddr(msg['From'])[1]
        date = msg['Date']
        
        # 提取正文
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    try:
                        charset = part.get_content_charset() or 'utf-8'
                        body = part.get_payload(decode=True).decode(charset, errors='replace')
                        break
                    except: pass
        else:
            try:
                charset = msg.get_content_charset() or 'utf-8'
                body = msg.get_payload(decode=True).decode(charset, errors='replace')
            except: pass
        
        # 提取信息
        info = {"material": None, "quantity": None, "tolerance": None, "surface": None, "ra": None}
        
        # 材料
        for pat in [r'材料[：:]\s*(\S+)', r'(6061|6063|304|碳钢|铝合金|不锈钢|铜|黄铜)', r'material[：:]*\s*(\S+)']:
            m = re.search(pat, body, re.IGNORECASE)
            if m: info["material"] = m.group(1); break
        
        # 数量
        for pat in [r'数量[：:]\s*(\d+)', r'qty[：:]*\s*(\d+)', r'(\d+)\s*件', r'共\s*(\d+)\s*个']:
            m = re.search(pat, body)
            if m: info["quantity"] = m.group(1); break
        
        # 公差
        for pat in [r'公差[：:]\s*([^\\s,，]+)', r'tolerance[：:]*\s*(\S+)', r'(ISO\s*\d+)']:
            m = re.search(pat, body, re.IGNORECASE)
            if m: info["tolerance"] = m.group(1); break
        
        # 表面处理
        for pat in [r'表面[处理]*[：:]\s*(\S+)', r'(阳极|电镀|喷砂|抛光|钝化)', r'surface[：:]*\s*(\S+)']:
            m = re.search(pat, body, re.IGNORECASE)
            if m: info["surface"] = m.group(1); break
        
        self.log(f"处理: {subject[:40]} from {sender}")
        self.log(f"  提取: 材料={info['material']}, 数量={info['quantity']}, 公差={info['tolerance']}, 表面={info['surface']}")
        
        return {"email": sender, "subject": subject, "date": date, "info": info}
    
    def run_once(self):
        self.log("=" * 50)
        self.log(f"Email Quote Worker V2 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.log("=" * 50)
        
        imap = self.connect_imap()
        if not imap: return
        
        try:
            imap.select("INBOX")
            _, msgs = imap.search(None, 'UNSEEN')
            ids = msgs[0].split() if msgs[0] else []
            self.log(f"发现 {len(ids)} 封未读邮件")
            
            for eid in ids[-20:]:
                try:
                    task = self.process_email(eid, imap)
                    if not task: continue
                    
                    # 标记已读
                    imap.store(eid, '+FLAGS', '\\\\Seen')
                    
                    # 保存任务
                    c = self.db.cursor()
                    c.execute("""
                        INSERT OR REPLACE INTO tasks_v2 
                        (customer_email, subject, received_at, status, material, quantity, tolerance, surface, tracking_id, updated_at)
                        VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)
                    """, (task["email"], task["subject"], task["date"],
                          task["info"].get("material"), task["info"].get("quantity"),
                          task["info"].get("tolerance"), task["info"].get("surface"),
                          self.quote_gen.tracking_id, datetime.now().isoformat()))
                    self.db.commit()
                    
                    # 检查信息是否完整
                    info = task["info"]
                    missing = [k for k, v in info.items() if not v and k in ["material", "quantity"]]
                    
                    if missing:
                        self.log(f"  ⚠️ 缺失: {missing}")
                        # 追问
                        self.send_followup(task["email"], task["subject"], missing)
                    else:
                        # 生成报价
                        quote = self.quote_gen.calc_quote(info["material"], info.get("surface") or "不处理", info["quantity"])
                        xlsx = self.quote_gen.generate_xlsx(info, quote)
                        self.quote_gen.send_email(task["email"], task["subject"], quote, xlsx)
                        self.log(f"  ✅ 报价完成: ¥{quote['total_with_tax']:.2f}")
                        
                        # 更新状态
                        c.execute("UPDATE tasks_v2 SET status='quoted', updated_at=? WHERE subject=?", 
                                (datetime.now().isoformat(), task["subject"]))
                        self.db.commit()
                
                except Exception as e:
                    self.log(f"  ❌ 处理异常: {e}")
        finally:
            try: imap.logout()
            except: pass
        
        self.log("✅ 完成")
        
        # 保存日志
        log_file = WORK_DIR / f"log_v2_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(log_file, 'a') as f:
            f.write("\n".join(self.logs) + "\n")
    
    def send_followup(self, to_email, subject, missing):
        """发送追问邮件"""
        config = self.config
        try:
            import smtplib, ssl
            body = f"""您好，

感谢询价！我们收到您的邮件「{subject}」，正在处理中。

请补充以下信息：
"""
            for i, m in enumerate(missing, 1):
                body += f"{i}. {m}\n"
            
            body += """
请回复本邮件告知，我们将立即提供精准报价。

timo报价智能自动报价
"""
            ctx = ssl.create_default_context()
            smtp = smtplib.SMTP_SSL("smtp.qq.com", 465, context=ctx)
            smtp.login(config["email_addr"], config["auth_code"])
            
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['From'] = config["email_addr"]
            msg['To'] = to_email
            msg['Subject'] = f"Re: {subject} - 请补充信息"
            smtp.send_message(msg)
            smtp.quit()
            
            self.log(f"  ✅ 已追问: {', '.join(missing)}")
        except Exception as e:
            self.log(f"  ❌ 追问失败: {e}")

def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--loop":
        interval = int(sys.argv[2]) if len(sys.argv) > 2 else 5
        worker = EmailQuoteWorkerV2()
        worker.log(f"启动监控 (间隔{interval}分钟)")
        while True:
            try:
                worker.run_once()
            except Exception as e:
                worker.log(f"异常: {e}")
            time.sleep(interval * 60)
    else:
        worker = EmailQuoteWorkerV2()
        worker.run_once()

if __name__ == "__main__":
    main()