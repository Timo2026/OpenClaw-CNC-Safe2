#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Email Quote Worker - 邮箱报价员工
自动扫描邮件 → 提取STEP附件 → 追问缺失信息 → 调用报价系统 → 发送报价单
"""

import os
import sys
import re
import json
import time
import email
import base64
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

HOME = Path.home()
SKILL_DIR = HOME / ".openclaw/skills/email-quote"
CONFIG_FILE = SKILL_DIR / "config/email_config.json"
DB_FILE = SKILL_DIR / "config/quote_tasks.db"
WORK_DIR = SKILL_DIR / "workspace"

# 邮件配置模板 (实际配置需用户填写真实信息)
DEFAULT_CONFIG = {
    "imap_server": "imap.qq.com",
    "imap_port": 993,
    "smtp_server": "smtp.qq.com",
    "smtp_port": 465,
    "email_addr": "",
    "auth_code": "",
    "scan_interval_minutes": 5,
    "auto_reply_missing": True,
    "max_retries": 3,
    "step_keywords": ["step", "stp", "cad", "图纸", "加工"],
    "required_fields": ["材料", "数量", "公差", "表面处理"]
}

WORK_DIR.mkdir(parents=True, exist_ok=True)

class EmailQuoteWorker:
    def __init__(self):
        self.config = self.load_config()
        self.db = self.init_db()
        self.logs = []
    
    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        self.logs.append(line)
        print(line)
    
    def load_config(self):
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        return DEFAULT_CONFIG.copy()
    
    def save_config(self, config):
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    
    def init_db(self):
        """初始化任务数据库"""
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(DB_FILE))
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_email TEXT,
                subject TEXT,
                received_at TEXT,
                status TEXT DEFAULT 'pending',
                material TEXT,
                quantity TEXT,
                tolerance TEXT,
                surface TEXT,
                ra TEXT,
                step_file TEXT,
                step_path TEXT,
                retry_count INTEGER DEFAULT 0,
                updated_at TEXT
            )
        """)
        conn.commit()
        return conn
    
    # === 邮件连接 ===
    
    def connect_imap(self):
        import imaplib, ssl
        try:
            ctx = ssl.create_default_context()
            self.imap = imaplib.IMAP4_SSL(self.config["imap_server"], 
                                          self.config["imap_port"], ssl_context=ctx)
            self.imap.login(self.config["email_addr"], self.config["auth_code"])
            self.log(f"✅ IMAP连接成功: {self.config['email_addr']}")
            return True
        except Exception as e:
            self.log(f"❌ IMAP连接失败: {e}")
            return False
    
    def connect_smtp(self):
        import smtplib, ssl
        try:
            ctx = ssl.create_default_context()
            self.smtp = smtplib.SMTP_SSL(self.config["smtp_server"], 
                                         self.config["smtp_port"], context=ctx)
            self.smtp.login(self.config["email_addr"], self.config["auth_code"])
            self.log(f"✅ SMTP连接成功")
            return True
        except Exception as e:
            self.log(f"❌ SMTP连接失败: {e}")
            return False
    
    def disconnect(self):
        try:
            if hasattr(self, 'imap'): self.imap.logout()
            if hasattr(self, 'smtp'): self.smtp.quit()
        except: pass
    
    # === 邮件扫描 ===
    
    def scan_emails(self):
        """扫描未处理的邮件"""
        if not self.connect_imap(): return []
        
        try:
            status, messages = self.imap.select("INBOX")
            if status != "OK":
                self.log("❌ 无法访问INBOX")
                return []
            
            # 搜索未读邮件
            status, msg_ids = self.imap.search(None, 'UNSEEN')
            
            if status != "OK":
                return []
            
            email_ids = msg_ids[0].split()
            self.log(f"发现 {len(email_ids)} 封邮件")
            
            tasks = []
            for eid in email_ids[-20:]:  # 最多处理20封
                try:
                    task = self.process_email(eid)
                    if task:
                        # 标记为已读
                        self.imap.store(eid, '+FLAGS', '\\Seen')
                        self.log(f"  已标记为已读")
                        tasks.append(task)
                except Exception as e:
                    self.log(f"处理邮件 {eid} 失败: {e}")
            
            return tasks
        except Exception as e:
            self.log(f"扫描失败: {e}")
            return []
        finally:
            self.disconnect()
    
    def process_email(self, msg_id):
        """处理单封邮件"""
        status, data = self.imap.fetch(msg_id, '(RFC822)')
        if status != 'OK': return None
        
        raw_email = data[0][1]
        msg = email.message_from_bytes(raw_email)
        
        subject = self.decode_header(msg['Subject'] or "无主题")
        sender = email.utils.parseaddr(msg['From'])[1]
        date = msg['Date']
        
        self.log(f"处理: {subject} from {sender}")
        
        # 检查是否已存在
        cursor = self.db.cursor()
        cursor.execute("SELECT id FROM tasks WHERE subject=? AND customer_email=?", (subject, sender))
        if cursor.fetchone():
            self.log(f"  已存在, 跳过")
            return None
        
        # 提取STEP附件
        step_attachments = self.extract_step_attachments(msg)
        
        # 提取邮件内容中的关键信息
        body = self.extract_body(msg)
        info = self.extract_info_from_body(body)
        
        # 保存任务
        cursor.execute("""
            INSERT INTO tasks (customer_email, subject, received_at, status, 
                             material, quantity, tolerance, surface, ra,
                             step_file, retry_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (sender, subject, date, 'pending',
             info.get('材料'), info.get('数量'), info.get('公差'),
             info.get('表面处理'), info.get('RA'),
             ','.join(step_attachments) if step_attachments else None,
             0)
        )
        self.db.commit()
        task_id = cursor.lastrowid
        
        self.log(f"  提取: 材料={info.get('材料')}, 数量={info.get('数量')}, 附件={len(step_attachments)}")
        
        return {
            "id": task_id,
            "sender": sender,
            "subject": subject,
            "body": body,
            "attachments": step_attachments,
            "info": info
        }
    
    def decode_header(self, header):
        if not header: return ""
        parts = email.header.decode_header(header)
        result = []
        for part, enc in parts:
            if isinstance(part, bytes):
                result.append(part.decode(enc or 'utf-8', errors='replace'))
            else:
                result.append(part)
        return " ".join(result)
    
    def extract_body(self, msg):
        """提取邮件正文"""
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                ct = part.get_content_type()
                if ct == "text/plain" or ct == "text/html":
                    try:
                        charset = part.get_content_charset() or 'utf-8'
                        body = part.get_payload(decode=True).decode(charset, errors='replace')
                        if ct == "text/plain":
                            break
                    except: pass
        else:
            try:
                charset = msg.get_content_charset() or 'utf-8'
                body = msg.get_payload(decode=True).decode(charset, errors='replace')
            except: pass
        return body
    
    def extract_info_from_body(self, body):
        """从邮件正文提取关键信息"""
        info = {}
        
        # 材料
        patterns = {
            "材料": [r'材料[：:]\s*(\S+)', r'material[：:]\s*(\S+)', 
                    r'材质[：:]\s*(\S+)', r'[\u4e00-\u9fa5]+钢', r'6061', r'304', r'铝合金'],
            "数量": [r'数量[：:]\s*(\d+)', r'qty[：:]*\s*(\d+)', r'件[：:]\s*(\d+)',
                    r'\d+\s*件', r'共\s*(\d+)\s*个'],
            "公差": [r'公差[：:]\s*([^\\s,，]+)', r'tolerance[：:]\s*([^\\s,]+)',
                    r'±\d+\.?\d*', r'\d+\.?\d*\s*mm'],
            "表面处理": [r'表面[：:]\s*(\S+)', r'处理[：:]\s*(\S+)',
                       r'阳极', r'电镀', r'喷砂', r'抛光', r'钝化'],
            "RA": [r'RA\s*[：:]\s*(\d+\.?\d*)', r'Ra\s*[：:]\s*(\d+\.?\d*)',
                  r'粗糙度[：:]\s*(\d+\.?\d*)']
        }
        
        for field, pats in patterns.items():
            for pat in pats:
                m = re.search(pat, body, re.IGNORECASE)
                if m:
                    info[field] = m.group(1) if m.lastindex else m.group(0)
                    break
        
        return info
    
    def extract_step_attachments(self, msg):
        """提取STEP附件"""
        steps = []
        for part in msg.walk():
            cd = part.get("Content-Disposition")
            if cd and "attachment" in cd:
                filename = part.get_filename()
                if filename:
                    fn = self.decode_header(filename)
                    if any(fn.lower().endswith(ext) for ext in ['.step', '.stp']):
                        steps.append(fn)
        return steps
    
    # === 缺失信息追问 ===
    
    def check_and_followup(self):
        """追问缺失信息的客户"""
        if not self.config.get("auto_reply_missing"): return
        
        if not self.connect_smtp(): return
        
        cursor = self.db.cursor()
        cursor.execute("""
            SELECT id, customer_email, subject FROM tasks 
            WHERE status='pending' AND retry_count < ?
        """, (self.config.get("max_retries", 3),))
        
        pending = cursor.fetchall()
        
        for task_id, email_addr, subject in pending:
            # 检查缺失字段
            cursor.execute("""
                SELECT material, quantity, tolerance, surface FROM tasks WHERE id=?
            """, (task_id,))
            row = cursor.fetchone()
            material, quantity, tolerance, surface = row
            
            missing = []
            if not material: missing.append("材料(铝合金/不锈钢/碳钢等)")
            if not quantity: missing.append("数量")
            if not tolerance: missing.append("公差要求")
            if not surface: missing.append("表面处理工艺")
            
            if missing:
                self.send_followup_email(task_id, email_addr, subject, missing)
        
        self.disconnect()
    
    def send_followup_email(self, task_id, to_email, subject, missing_fields):
        """发送追问邮件"""
        body = f"""您好，

感谢您的询价！我们已收到您的邮件「{subject}」，正在处理中。

为确保报价准确，请补充以下信息：

"""
        for i, field in enumerate(missing_fields, 1):
            body += f"{i}. {field}\n"
        
        body += """
请回复本邮件告知以上信息，我们将在收到后立即为您提供精准报价。

此致

智能报价系统
"""
        
        try:
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['From'] = self.config["email_addr"]
            msg['To'] = to_email
            msg['Subject'] = f"Re: {subject} - 请补充报价信息"
            
            self.smtp.send_message(msg)
            
            # 更新重试次数
            cursor = self.db.cursor()
            cursor.execute("UPDATE tasks SET retry_count=retry_count+1, updated_at=? WHERE id=?", 
                         (datetime.now().isoformat(), task_id))
            self.db.commit()
            
            self.log(f"✅ 已追问 {to_email}: {', '.join(missing_fields)}")
        except Exception as e:
            self.log(f"❌ 追问失败: {e}")
    
    # === 报价处理 ===
    
    def generate_quote(self, task_id):
        """生成报价单"""
        cursor = self.db.cursor()
        cursor.execute("""
            SELECT customer_email, subject, material, quantity, tolerance, surface, ra, step_path
            FROM tasks WHERE id=?
        """, (task_id,))
        row = cursor.fetchone()
        if not row:
            self.log(f"❌ 任务 {task_id} 不存在")
            return None
        
        sender, subject, material, quantity, tolerance, surface, ra, step_path = row
        
        if not material or not quantity:
            self.log(f"⚠️ 信息不足, 跳过: 材料={material}, 数量={quantity}")
            return None
        
        # 调用 P-Tuning 报价系统
        try:
            sys.path.insert(0, str(HOME / ".openclaw/skills/metal-kbs/scripts"))
            from knowledge_graph import MetalKBS
            
            kbs = MetalKBS()
            _, quote_data = {}, {"median_price": 36.52}
            
            # 计算报价
            qty = int(re.search(r'\d+', str(quantity)).group()) if quantity else 10
            surf = surface or "不处理"
            
            mat_coef, surf_coef, _ = kbs.get_price_coef(material, surf)
            median_price, _ = 36.52, "default"
            
            base = median_price * mat_coef
            surface_cost = base * surf_coef
            unit_price = base + surface_cost
            total = unit_price * qty
            profit = total * 0.25
            final = total + profit
            
            # 生成报价单
            quote_file = self.create_quote_xlsx(
                subject, material, surf, qty, unit_price, final
            )
            
            # 更新任务状态
            cursor.execute("""
                UPDATE tasks SET status='quoted', updated_at=? WHERE id=?
            """, (datetime.now().isoformat(), task_id))
            self.db.commit()
            
            self.log(f"✅ 报价完成: ¥{final:.2f}")
            return {
                "total": final,
                "quote_file": quote_file,
                "to_email": sender
            }
        except Exception as e:
            self.log(f"❌ 报价失败: {e}")
            return None
    
    def create_quote_xlsx(self, project_name, material, surface, quantity, unit_price, total):
        """生成XLSX报价单"""
        import openpyxl
        from openpyxl.styles import Font, Alignment
        
        DATE = datetime.now().strftime("%Y-%m-%d")
        DATETIME = datetime.now().strftime("%Y%m%d_%H%M%S")
        QUOTE_DIR = WORK_DIR / "quotes"
        QUOTE_DIR.mkdir(parents=True, exist_ok=True)
        
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "CNC报价单"
        
        ws.column_dimensions['A'].width = 18
        ws.column_dimensions['B'].width = 15
        ws.column_dimensions['C'].width = 10
        ws.column_dimensions['D'].width = 12
        ws.column_dimensions['E'].width = 15
        
        ws['A1'] = "CNC加工报价单"
        ws['A1'].font = Font(size=14, bold=True)
        ws['A1'].alignment = Alignment(horizontal='center')
        ws.merge_cells('A1:E1')
        
        ws['A3'] = "项目:"
        ws['B3'] = project_name
        ws['A4'] = "日期:"
        ws['B4'] = DATE
        
        headers = ["材料", "表面处理", "数量", "单价(元)", "总价(元)"]
        for i, h in enumerate(headers, 1):
            c = ws.cell(row=6, column=i, value=h)
            c.font = Font(bold=True)
        
        ws['A7'] = f"{material} / {surface}"
        ws['C7'] = quantity
        ws['D7'] = round(unit_price, 2)
        ws['E7'] = round(total, 2)
        
        ws['D9'] = "总计:"
        ws['D9'].font = Font(bold=True)
        ws['E9'] = round(total, 2)
        ws['E9'].font = Font(bold=True)
        
        path = QUOTE_DIR / f"报价单_{DATETIME}.xlsx"
        wb.save(str(path))
        return path
    
    def send_quote_email(self, quote_info):
        """发送报价邮件"""
        if not self.connect_smtp(): return
        
        try:
            to_email = quote_info["to_email"]
            quote_file = quote_info["quote_file"]
            total = quote_info["total"]
            
            body = f"""您好，

感谢您的询价！请查收附件中的报价单。

报价金额: ¥{total:.2f} (含利润25%)

报价单包含:
- 材料与表面处理明细
- 数量与单价
- 总价

如有任何疑问，请回复此邮件。

智能报价系统
"""
            msg = MIMEMultipart()
            msg['From'] = self.config["email_addr"]
            msg['To'] = to_email
            msg['Subject'] = f"Re: 您的询价 - CNC加工报价 ¥{total:.2f}"
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            # 添加附件
            with open(quote_file, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename=报价单.xlsx')
                msg.attach(part)
            
            self.smtp.send_message(msg)
            self.log(f"✅ 报价已发送至 {to_email}")
        except Exception as e:
            self.log(f"❌ 发送失败: {e}")
        finally:
            self.disconnect()
    
    # === 主流程 ===
    
    def process_all(self):
        """处理所有待报价任务"""
        cursor = self.db.cursor()
        cursor.execute("SELECT id FROM tasks WHERE status='pending'")
        pending = [row[0] for row in cursor.fetchall()]
        
        for task_id in pending:
            quote_info = self.generate_quote(task_id)
            if quote_info:
                self.send_quote_email(quote_info)
    
    def run_once(self):
        """单次运行"""
        self.log("=" * 50)
        self.log(f"Email Quote Worker - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.log("=" * 50)
        
        # 1. 扫描新邮件
        self.scan_emails()
        
        # 2. 追问缺失信息
        self.check_and_followup()
        
        # 3. 处理待报价任务
        self.process_all()
        
        self.log("✅ 本次处理完成")
        
        # 保存日志
        log_file = WORK_DIR / f"log_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(log_file, 'a') as f:
            f.write("\n".join(self.logs) + "\n")
    
    def run_loop(self, interval_minutes=5):
        """循环运行"""
        self.log(f"启动邮箱监控 (间隔{interval_minutes}分钟)")
        while True:
            try:
                self.run_once()
            except Exception as e:
                self.log(f"❌ 运行异常: {e}")
            time.sleep(interval_minutes * 60)

def main():
    worker = EmailQuoteWorker()
    
    if len(sys.argv) > 1 and sys.argv[1] == "--setup":
        # 配置向导
        print("Email Quote Worker 配置向导")
        email_addr = input("邮箱地址: ").strip()
        auth_code = input("授权码: ").strip()
        
        worker.config["email_addr"] = email_addr
        worker.config["auth_code"] = auth_code
        worker.save_config(worker.config)
        
        # 测试连接
        print("\n测试连接...")
        if worker.connect_imap():
            print("✅ IMAP连接成功")
            worker.imap.logout()
        if worker.connect_smtp():
            print("✅ SMTP连接成功")
            worker.smtp.quit()
        
        print(f"\n配置已保存至: {CONFIG_FILE}")
        return
    
    if len(sys.argv) > 1 and sys.argv[1] == "--status":
        # 查看状态
        cursor = worker.db.cursor()
        cursor.execute("SELECT status, COUNT(*) FROM tasks GROUP BY status")
        for status, count in cursor.fetchall():
            print(f"  {status}: {count}")
        return
    
    if len(sys.argv) > 1 and sys.argv[1] == "--loop":
        interval = int(sys.argv[2]) if len(sys.argv) > 2 else 5
        worker.run_loop(interval)
    else:
        worker.run_once()

if __name__ == "__main__":
    main()