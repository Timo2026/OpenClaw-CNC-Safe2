---
name: email-quote
description: 邮箱报价员工V2 - 专业CNC报价单模板。自动扫描邮件→提取STEP/材料/数量/公差/表面处理→追问缺失信息→调用P-Tuning+Metal-KBS报价→发送专业XLSX报价单。
metadata:
  {
    "openclaw": {
      "emoji": "📧",
    },
  }
---

# Email Quote Worker V2 - 专业CNC报价单模板

## 核心功能

| 功能 | 说明 |
|------|------|
| 专业报价单 | 匹配 Singapore CNC Tech 报价单格式 |
| 自动扫描 | 每5分钟扫描QQ邮箱新邮件 |
| 信息提取 | 材料/数量/公差/RA/表面处理 |
| 智能追问 | 缺失关键信息自动邮件追问 |
| P-Tuning报价 | 调用Metal-KBS真实计算 |
| 自动回复 | 发送专业XLSX报价单 |

## 新增文件

```
email-quote/
├── SKILL.md                           # 技能说明
├── config/
│   └── email_config.json              # 邮箱配置
├── scripts/
│   ├── email_quote_worker.py         # V1 (旧版)
│   ├── email_quote_worker_v2.py      # V2专业版 ⭐
│   └── cnc_quote_template.py          # 专业报价单生成器 ⭐
└── workspace/
    └── quotes/                        # 报价单输出目录
```

## 专业报价单格式

```
┌─────────────────────────────────────────────┐
│           CNC 加工报价单                      │
├─────────────────────────────────────────────┤
│ 零件信息              │ 订单信息              │
│ 材料: AL6061         │ 数量: 10             │
│ 公差: ISO 2768普通级 │ 地区: 中国           │
│ 表面: 阳极氧化本色   │ GST: 0.00%           │
├─────────────────────────────────────────────┤
│ 成本明细                                    │
│ 项目        不含税单价  含税单价  数量  总计 │
│ 零件AL6061   ¥48.21    ¥48.21    10   ¥482 │
├─────────────────────────────────────────────┤
│                        总计 (RMB): ¥482.06   │
└─────────────────────────────────────────────┘
```

## 报价计算

| 项目 | 来源 | 说明 |
|------|------|------|
| 基准价 ¥36.52 | P-Tuning学习 | 来自298份XLSX清洗 |
| 材料系数 | Metal-KBS | 6061=1.2x, 304=1.5x |
| 表面系数 | Metal-KBS | 阳极氧化=0.15x, 钝化=0.05x |
| 批量系数 | P-Tuning学习 | 10件=1.0x |
| 利润加成 | 行业规则 | 25% |

## 使用方式

```bash
# 启动V2专业版 (后台运行)
nohup python3 ~/.openclaw/skills/email-quote/scripts/email_quote_worker_v2.py --loop 5 &

# 单独测试报价生成
python3 ~/.openclaw/skills/email-quote/scripts/cnc_quote_template.py AL6061 "阳极氧化本色" 10

# 查看状态
ps aux | grep email_quote_worker_v2
```

## 定时任务建议

```bash
# 建议添加cron每日02:00检查
openclaw cron add --name "Email Quote V2" --schedule "0 2 * * *" -- python3 ~/.openclaw/skills/email-quote/scripts/email_quote_worker_v2.py
```

## 依赖 Skills

- `metal-kbs` - 工艺规则与系数
- `cad-ptuning` - CAD参数
- `quote-ptuning` - 报价数据