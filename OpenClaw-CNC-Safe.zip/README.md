# OpenClaw CNC 智能报价系统

CNC画图 + 智能报价 + 邮件发送 一体化工作流

## 功能

- **图纸生成**: 基于 PythonOCC 生成 STEP 文件
- **智能报价**: 基于真实数据学习的报价引擎  
- **邮件发送**: 自动生成 XLSX 报价单并发送

## 架构

```
用户需求 → orchestrator → step-factory → STEP文件
                        → quote-ptuning → 报价结果
                        → email-quote → 邮件发送
```

## SKILL 调用记录

| SKILL | 功能 | 状态 |
|-------|------|------|
| orchestrator | 技能编排器 | ✅ |
| step-factory | 图纸生成 | ✅ |
| quote-ptuning | 报价计算 | ✅ |
| email-quote | 邮件发送 | ✅ |

## 安装

```bash
pip install aiohttp openpyxl
```

## 配置

复制 `email-quote/config/config.example.yaml` 为 `config.yaml`，填入真实邮件信息。

## 使用

```bash
# 画图+报价
python3 orchestrator/scripts/orchestrator.py --request "法兰报价，材料6061-T6，数量10件"

# 启动 Web UI
python3 cnc_draw_quote_api.py
```

## 注意

- 核心报价数据需自行准备
- 不要将 config.yaml 上传至公开仓库

MIT License