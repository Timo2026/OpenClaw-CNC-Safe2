---
name: orchestrator
description: 智能编排器 - 自动发现并调用其他SKILL的能力，支持任务分解、能力匹配、工作流执行。用于处理需要多步骤、多技能协作的复杂请求。
capabilities:
 - name: orchestrate
   description: 接收任意复杂任务，自动分解、匹配能力、生成执行计划并调用子技能。
   parameters:
     - name: request
       type: string
       required: true
       description: 用户原始请求（自然语言）
     - name: workflow_name
       type: string
       required: false
       description: 可选，指定预定义工作流名称（如 flange_quote）
   output: 最终执行结果（文本/文件路径/JSON）
   invoke:
     type: python_function
     module: "orchestrator.scripts.orchestrator"
     function: "run_orchestrator"
---
