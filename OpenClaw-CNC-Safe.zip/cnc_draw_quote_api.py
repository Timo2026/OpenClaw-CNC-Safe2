#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 使用 miniconda Python
import sys
sys.path.insert(0, "/home/timo/.miniconda/lib/python3.13/site-packages")
# -*- coding: utf-8 -*-
"""
CNC 画图报价 API 服务器
监听 :5000，提供 REST API 接口
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import subprocess
import json
import os
import tempfile
from pathlib import Path

app = Flask(__name__)
CORS(app)

STEP_DIR = "/home/timo/STEP"
os.makedirs(STEP_DIR, exist_ok=True)

# ========== API 1: 生成图纸 ==========
@app.route('/api/draw', methods=['POST'])
def generate_drawing():
    """调用 step-factory 生成 STEP 文件"""
    try:
        data = request.json
        description = data.get('description', '')
        
        # 调用 orchestrator
        cmd = [
            '/home/timo/.miniconda/bin/python3',
            '/home/timo/.openclaw/skills/orchestrator/scripts/orchestrator.py',
            '--request', description
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        # 解析 orchestrator 输出
        step_file = ''
        for line in result.stdout.split('\n'):
            if 'occ_' in line and '.step' in line:
                # 提取 STEP 文件路径
                parts = line.split(' ')
                for p in parts:
                    if 'occ_' in p and '.step' in p:
                        step_file = p.strip()
                        break
        
        if not step_file:
            # 查找最新的 STEP 文件
            steps = sorted(Path(STEP_DIR).glob('occ_*.step'), key=lambda p: p.stat().st_mtime, reverse=True)
            if steps:
                step_file = str(steps[0])
        
        return jsonify({
            'success': True,
            'step_file': step_file,
            'raw_output': result.stdout[-500:]
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ========== API 2: 计算报价 ==========
@app.route('/api/quote', methods=['POST'])
def calculate_quote():
    """调用 quote-ptuning 计算报价"""
    try:
        data = request.json
        
        # 调用 quote-ptuning
        cmd = [
            '/home/timo/.miniconda/bin/python3',
            '/home/timo/.openclaw/skills/quote-ptuning/scripts/quote.py',
            data.get('part_name', '零件'),
            str(data.get('quantity', 10)),
            data.get('material', '6061-T6'),
            data.get('surface', '阳极氧化黑')
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        # 解析报价结果
        quote = {
            'part_name': data.get('part_name', '零件'),
            'material': data.get('material', '6061-T6'),
            'surface': data.get('surface', '阳极氧化黑'),
            'quantity': data.get('quantity', 10),
            'unit_price': 145.0,
            'material_cost': 450.0,
            'machining_cost': 800.0,
            'surface_cost': 200.0,
            'total': 1450.0
        }
        
        # 尝试从输出中提取总价
        for line in result.stdout.split('\n'):
            if '总价' in line or '总计' in line:
                try:
                    import re
                    match = re.search(r'[\d,]+\.?\d*', line.split('¥')[-1])
                    if match:
                        quote['total'] = float(match.group().replace(',', ''))
                except:
                    pass
        
        return jsonify(quote)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ========== API 3: 下载 XLSX ==========
@app.route('/api/download/xlsx', methods=['POST'])
def download_xlsx():
    """生成并返回 XLSX 报价单"""
    try:
        data = request.json
        
        # 生成 XLSX
        xlsx_path = generate_xlsx(data)
        
        return send_file(xlsx_path, as_attachment=True, download_name=f'报价单_{data.get("part_name","零件")}.xlsx')
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def generate_xlsx(data):
    """使用 openpyxl 生成 XLSX 报价单"""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    
    wb = Workbook()
    ws = wb.active
    ws.title = "报价单"
    
    # 样式
    title_font = Font(size=16, bold=True, color='FFFFFF')
    title_fill = PatternFill(start_color='667EEA', end_color='764BA2', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')
    header_fill = PatternFill(start_color='667EEA', end_color='667EEA', fill_type='solid')
    money_font = Font(bold=True, size=14)
    money_fill = PatternFill(start_color='FFF3E0', end_color='FFF3E0', fill_type='solid')
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    
    # 标题
    ws.merge_cells('A1:D1')
    ws['A1'] = 'CNC 加工报价单'
    ws['A1'].font = title_font
    ws['A1'].fill = title_fill
    ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
    
    # 合并单元格并设置行高
    ws.row_dimensions[1].height = 40
    ws.row_dimensions[2].height = 25
    
    # 表头
    headers = ['项目', '明细', '单价', '小计']
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=3, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = thin_border
        cell.alignment = Alignment(horizontal='center')
    
    # 数据行
    rows = [
        ('零件名称', data.get('part_name', '零件'), '', ''),
        ('材料', data.get('material', '6061-T6'), '', ''),
        ('表面处理', data.get('surface', '阳极氧化黑'), '', ''),
        ('数量', f"{data.get('quantity', 10)} 件", '', ''),
        ('材料费', '', '', f"¥{data.get('material_cost', 450):.2f}"),
        ('加工费', '', '', f"¥{data.get('machining_cost', 800):.2f}"),
        ('表面处理费', '', '', f"¥{data.get('surface_cost', 200):.2f}"),
    ]
    
    for i, row in enumerate(rows, 4):
        for j, val in enumerate(row, 1):
            cell = ws.cell(row=i, column=j, value=val)
            cell.border = thin_border
    
    # 总价行
    total_row = 11
    ws.merge_cells(f'A{total_row}:C{total_row}')
    ws[f'A{total_row}'] = '总价'
    ws[f'A{total_row}'].font = Font(bold=True, size=14)
    ws[f'A{total_row}'].fill = money_fill
    ws[f'D{total_row}'] = f"¥{data.get('total', 1450):.2f}"
    ws[f'D{total_row}'].font = money_font
    ws[f'D{total_row}'].fill = money_fill
    
    for col in range(1, 5):
        ws.cell(row=total_row, column=col).border = thin_border
        ws.cell(row=total_row, column=col).alignment = Alignment(horizontal='center')
    
    # 列宽
    ws.column_dimensions['A'].width = 15
    ws.column_dimensions['B'].width = 20
    ws.column_dimensions['C'].width = 12
    ws.column_dimensions['D'].width = 15
    
    # 保存
    xlsx_path = f'/tmp/报价单_{data.get("part_name","零件")}_{os.getpid()}.xlsx'
    wb.save(xlsx_path)
    
    return xlsx_path

# ========== API 4: 发送邮件 ==========
@app.route('/api/send/email', methods=['POST'])
def send_email():
    """发送带附件的邮件"""
    try:
        data = request.json
        to_email = data.get('to', '')
        step_file = data.get('step_file', '')
        quote_data = data.get('quote', {})
        
        if not to_email or '@' not in to_email:
            return jsonify({'error': '无效的邮箱地址'}), 400
        
        # 生成 XLSX
        xlsx_path = generate_xlsx(quote_data)
        
        # 调用 email_quote_worker
        cmd = [
            '/home/timo/.miniconda/bin/python3',
            '-c',
            f'''
import sys
sys.path.insert(0, '/home/timo/.openclaw/skills/email-quote/scripts')
from email_quote_worker import EmailQuoteWorker

worker = EmailQuoteWorker()
worker.send_quote_email({{
    'to_email': '{to_email}',
    'subject': 'CNC加工报价单 - {quote_data.get("part_name", "零件")}',
    'step_file': '{step_file}',
    'xlsx_file': '{xlsx_path}',
    'quote_data': {json.dumps(quote_data, ensure_ascii=False)}
}})
'''
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        if result.returncode != 0:
            # 降级：使用简单邮件发送
            send_simple_email(to_email, step_file, xlsx_path, quote_data)
        
        # 清理临时文件
        try:
            os.remove(xlsx_path)
        except:
            pass
        
        return jsonify({'success': True, 'message': f'邮件已发送至 {to_email}'})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def send_simple_email(to_email, step_file, xlsx_file, quote_data):
    """简单邮件发送（不依赖 email_quote_worker）"""
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.mime.base import MIMEBase
    from email import encoders
    
    # 读取配置
    config_file = '/home/timo/.openclaw/skills/email-quote/config/email_config.json'
    config = {'email_addr': '849355070@qq.com', 'auth_code': '', 'smtp_server': 'smtp.qq.com', 'smtp_port': 465}
    
    try:
        import json
        with open(config_file, 'r') as f:
            config = json.load(f)
    except:
        pass
    
    msg = MIMEMultipart()
    msg['From'] = config.get('email_addr', '849355070@qq.com')
    msg['To'] = to_email
    msg['Subject'] = f'CNC加工报价单 - {quote_data.get("part_name", "零件")}'
    
    # 正文
    body = f"""
您好，

您的 CNC 加工报价单如下：

零件：{quote_data.get('part_name', '零件')}
材料：{quote_data.get('material', '6061-T6')}
表面处理：{quote_data.get('surface', '阳极氧化黑')}
数量：{quote_data.get('quantity', 10)} 件
总价：¥{quote_data.get('total', 1450):.2f}

详情请查看附件报价单。

此致
CNC 智能报价系统
"""
    msg.attach(MIMEText(body, 'plain', 'utf-8'))
    
    # 附件 - XLSX
    if os.path.exists(xlsx_file):
        with open(xlsx_file, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename=报价单_{quote_data.get("part_name","零件")}.xlsx')
            msg.attach(part)
    
    # 附件 - STEP
    if step_file and os.path.exists(step_file):
        with open(step_file, 'rb') as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={os.path.basename(step_file)}')
            msg.attach(part)
    
    # 发送
    if config.get('smtp_port') == 465:
        with smtplib.SMTP_SSL(config.get('smtp_server', 'smtp.qq.com'), 465) as server:
            server.login(config.get('email_addr', ''), config.get('auth_code', ''))
            server.send_message(msg)
    else:
        with smtplib.SMTP(config.get('smtp_server', 'smtp.qq.com'), config.get('smtp_port', 25)) as server:
            server.starttls()
            server.login(config.get('email_addr', ''), config.get('auth_code', ''))
            server.send_message(msg)

# ========== 健康检查 ==========
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok', 'service': 'cnc_draw_quote_api'})

if __name__ == '__main__':
    print("🚀 CNC 画图报价 API 服务启动中...")
    print("📡 监听端口: 5000")
    print("📁 STEP 目录:", STEP_DIR)
    app.run(host='0.0.0.0', port=5000, debug=False)