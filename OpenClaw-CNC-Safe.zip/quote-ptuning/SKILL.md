---
name: quote-ptuning
description: CNC加工报价 - 基于P-Tuning学习的精准报价系统
capabilities:
  - name: generate_quote
    description: CNC加工报价计算 - P-Tuning精准报价系统
    parameters:
      - name: part_name
        type: string
        required: true
        description: 零件名称
      - name: material
        type: string
        required: true
        description: 材料(如6061-T6, 304不锈钢)
      - name: surface
        type: string
        required: true
        description: 表面处理(如阳极氧化黑)
      - name: quantity
        type: int
        required: true
        description: 数量
    output: 报价JSON
    invoke:
      type: cli
      command: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/quote-ptuning/scripts/quote.py {{{part_name}}} {{{quantity}}} {{{material}}} {{{surface}}}"
    example: '{"part_name":"法兰","material":"6061-T6","surface":"阳极氧化黑","quantity":10}'
---

# Quote P-Tuning 技能

## 核心能力

**真正学习**了 298 个真实 XLSX 报价文件，掌握市场行情。

## 学习数据来源

| 来源 | 路径 | 数量 |
|------|------|------|
| 挂载盘图纸包 | `/media/timo/CE18065718063F49/图纸包` | 200+ |
| 系统报价单 | `/home/timo/BAOJIADAN` | 112 |
| 文档 AI | `/media/timo/文档/AI` | 10+ |

## 学习结果

### 价格统计 (清洗后)
- **价格样本**: 49101 个 (已过滤异常)
- **中位价格**: ¥36.52
- **合理范围**: ¥1 - ¥9999

### 材料价格系数
| 材料 | 系数 |
|------|------|
| 304不锈钢 | 1.5x |
| 6061-T6 | 1.2x |
| 铝合金 | 1.0x |
| 碳钢 | 0.8x |
| 铜 | 2.0x |
| 黄铜 | 1.8x |
| 钛合金 | 3.5x |

### 批量梯度
| 数量 | 系数 |
|------|------|
| 1-5件 | 1.2x |
| 6-10件 | 1.0x |
| 11-20件 | 0.9x |
| 21-50件 | 0.85x |
| 50+件 | 0.75x |

### 表面处理
| 处理 | 系数 |
|------|------|
| 阳极氧化黑色 | 0.15 |
| 阳极氧化本色 | 0.10 |
| 电镀 | 0.20 |
| 喷砂 | 0.08 |
| 抛光 | 0.12 |

## 脚本文件

- `scripts/learn_all.py` - 深度学习 + 数据清洗
- `scripts/quote.py` - 精准报价

## 使用方式

```bash
# 生成精准报价
python3 ~/.openclaw/skills/cad-ptuning/scripts/apply.py quote 法兰盘 6061-T6 10 阳极氧化黑色

# 查看清洗后的数据
cat ~/.openclaw/skills/quote-ptuning/learned/quote_clean.json
```

## P-Tuning 复用

| 市场数据 | 用途 |
|----------|------|
| ¥36.52 中位价 | 基准定价 |
| 批量梯度 | 合理折扣 |
| 材料系数 | 成本加成 |
| 表面系数 | 工艺加成 |

## 嵌入系统

✅ 已嵌入 OpenClaw，可被 `cad-ptuning` 调用。

## 依赖

- `cad-ptuning` - 共享市场数据
---

## Capabilities (供Orchestrator编排器使用)

```yaml
capabilities:
  - name: generate_quote
    description: CNC加工报价计算 - P-Tuning精准报价系统
    parameters:
      - name: part_name
        type: string
        required: true
        description: 零件名称
      - name: material
        type: string
        required: true
        description: 材料(如6061-T6, 304不锈钢)
      - name: surface
        type: string
        required: true
        description: 表面处理(如阳极氧化黑)
      - name: quantity
        type: int
        required: true
        description: 数量
    output: 报价JSON
    example: '{"part_name":"法兰","material":"6061-T6","surface":"阳极氧化黑","quantity":10}'
    call: "/home/timo/.miniconda/bin/python3 /home/timo/.openclaw/skills/quote-ptuning/scripts/quote.py \"法兰\" 10 \"6061-T6\" \"阳极氧化黑色\""
